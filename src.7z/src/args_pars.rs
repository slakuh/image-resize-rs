extern crate image;

use constants;
use image::ImageFormat;
use help;
use std::env;
use std::fs::metadata;
use std::path::PathBuf;
use img::{self, Resize};

#[derive(Clone)]
pub struct Arguments
{
    pub width: u32,
    pub height: u32,
    //pub image_size: img::ImgSize,
    pub filter: image::FilterType,
    pub images: Vec<PathBuf>,
    pub image_format: ImageFormat,
    pub resize: Resize,
    pub threads: u32,
}
/*
impl Arguments
{
    fn new () -> Arguments { 
        Arguments {
            width: 0,
            height: 0,
            filter: FilterType::Nearest,
        }
    }
}
*/
impl Arguments
{
    pub fn new() -> Arguments
    {

        let mut arg = Arguments{
            width : 0,
            height : 0,
            filter : image::FilterType::Nearest,
            images : Vec::new(),
            image_format: ImageFormat::JPEG,
            resize: Resize::Decrease,
            threads : 0,//thread_num(),
        };

        for argument in env::args().skip(1) 
        {       


            if let Some(index_0) = argument.chars().nth(0)
            {
                if index_0  == '-'
                { 
                    println!("Input argument: {}", argument);
                    
                    let str_vec: Vec<&str> = argument.split(':').collect();                
                
                    match str_vec[0]
                    {
                        "-h" => arg.height = str_vec[1].parse::<u32>().unwrap(),// arg_to_u32(str_vec[1]),
                        "-w" => arg.width = str_vec[1].parse::<u32>().unwrap(),//arg_to_u32(str_vec[1]),
                        "-help" => println!("{}", help::help()),
                        "-f" => arg.filter = filter(str_vec[1]),
                        "-if" => arg.image_format = image_format(str_vec[1]),
                        "-r" => arg.resize =  resize_type(str_vec[1]),
                        "-about" => help::about(),
                        "-t" => arg.threads = str_vec[1].parse::<u32>().unwrap(),//arg_to_u32(str_vec[1]),
                        _ => println!("Unsupported argument {}", argument),
                    }
                    continue;                    
                }                
            }

            match metadata(&argument)
            {
                Err(e) => println!("Argument isn't file, error message: {}", e),
                Ok(v) => 
                    if v.is_file() 
                    { 
                        /* if first_file {
                            first_file = false;
                        }  */

                        arg.images.push(PathBuf::from(argument)); 
                        continue; // znam da je nepotrebno ... možda ću dodavati još argumenata
                    },            
            }      
        }
        
        arg
        //println!("{} x {}", size.width, size.height);
        //println!("{:?}", file_vec);
    }
}

fn image_format(s: &str) -> ImageFormat
{
    let image_format: ImageFormat;
    match s {
        "jpg" => image_format = ImageFormat::JPEG,
        "png" => image_format = ImageFormat::PNG,
        _ => panic!("Unsupported argument image format"),
    }
    //println("arg_pars::image_format{:?}");
    image_format
}

fn resize_type(s: &str) -> img::Resize
{
    let resize: img::Resize;
    match s {
        "0" => resize = Resize::Neather,
        "1" => resize = Resize::Decrease,
        "2" => resize = Resize::Increase,
        "3" => resize = Resize::Eather,
        _ => panic!("Unsupported argument resize type"),
    }
    //println("arg_pars::resize_type\n{:?}", resize);
    resize
} 

fn filter(s: &str) -> image::FilterType {
    let ft: image::FilterType;//::Nearest;
    match s {
        "n" => ft = image::FilterType::Nearest,
        "t" => ft = image::FilterType::Triangle,
        "c" => ft = image::FilterType::CatmullRom,
        "g" => ft = image::FilterType::Gaussian,
        "l" => ft = image::FilterType::Lanczos3,
        _ => panic!("Unsupported argument filter"),
    }
    //println("arg_pars::filter\n{:?}", ft);
    ft
}

/*
fn thread_num() -> u32
{
    let cpu_num: u32;
    if let Some(cpu) = env::var_os("NUMBER_OF_PROCESSORS"){
        let cpu_str: &str = cpu.to_str().unwrap();
        cpu_num = cpu_str.parse::<u32>().unwrap();
    }
    else
    {
        cpu_num = constants::NUM_THREADS;
    }
    println!("CPU: {}", cpu_num);
    cpu_num
}
*/

/*
fn arg_to_u32(s: &str) -> u32
{
    //let mut number = 0u32;
    let mut num_string = String::new();
    
    for chr in s.chars()
    {
        if chr.is_digit(10)
        {
            num_string = num_string + &char::to_string(&chr); 
        }
    }

    match num_string.parse::<u32>() 
    {
        Ok(n) => return n,
        Err(e) => panic!(e),
    }
}
*/

/*
pub fn arguments()
{
    for argument in env::args() {
    println!("{}", argument);
    }
    pause_cmd();
}
*/    

/*
fn pause_cmd()
{
    let mut input = String::new();
    println!("Press ENTER to exit: ");
    match io::stdin().read_line(&mut input) {
        Ok(n) => {
            //println!("{} bytes read", n);
            //println!("{}", input);
            println!("Exiting...");
        }
        Err(error) => println!("error: {}", error),
    }
}

pub fn args_pars_main()
{
    //let num = arg_to_u32("-w250");
   // println!("fn arg_to_u32 = {}", num);
    let mut file_vec: Vec<PathBuf> = Vec::new();
    let mut size = ImgSize{width:0, height:0};
    
    arguments(&mut size, &mut file_vec);
    
    println!("{} x {}", size.width, size.height);
    println!("{:?}", file_vec);
    //pause_cmd();
} 
*/