pub const OUTPUT_WIDTH: u32 = 720;
pub const NUM_THREADS: u32 = 1;
// pub const OUTPUT_HEIGHT: u32 = 400;
pub const SUPPORTED_FILES: &'static [&'static str] = &["jpg", "png", "jpeg", "gif", "bmp", "tif",
                                                       "tiff"];
pub const AUTHOR: &'static str = "Slaven Kuhinek <skuhinek@gmail.com> © 2016";