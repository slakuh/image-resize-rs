use constants;

pub fn help() -> &'static str
{
    "

    Argumenti:

        -help

        -about

        -w -h
                Širina i/ili visina slike u pikselima.
                Dovoljno je upotrijebiti samo jedan argument,
                slici ća biti promijenjena veličina zadržavajući porporcije.

                • Upotreba: -w:640 i/ili -h:330

                Ukoliko se ne upotrijebi niti jedan argument
                tada će vrijednost za širinu biti 720px,
                a visina proporcionalna širini.
        ----------------------------------------------------------------------------
        -f 
                Filter koji će se koristiti prilikom promijene veličine slike.
                Vrijednosti za filter su:
                    n -> Nearest, Nearest Neighbor
                    t -> Triangle, Linear Filter
                    c -> CatmullRom, Cubic Filter (dobar omjer brzine i kvalitete)
                    g -> Gaussian, Gaussian Filter
                    l -> Lanczos3, Lanczos with window 3 

                • Upotreba: -f:c

                Ukoliko se ne upotrijebi argument za filter,
                tada će se koristiti Nearest Neighbor.
        ----------------------------------------------------------------------------
        -if 
                Format (Image Format) u kojem će slike biti spremljene. 
                Podržana su dva formata:
                    jpg -> slike će biti spremljene u JPEG formatu
                    png -> slike će biti spremljene u PNG formatu

                • Upotreba: -if:png

                Ukolike se ne upotrijebi argument za format, 
                slike će biti spremljene u JPG.
        ----------------------------------------------------------------------------        
        -r
                Načini na koji će se mijenjati veličina forografije.
                    0 -> slici NEĆE biti promjenjena veličina. 
                         Može se upotrijebiti za konverziju iz jednog
                         formata u drugi.
                    1 -> slika će biti UMANJENA , ali ne i uvećana  
                         ako je manja od zadane vrijednosti.
                    2 -> slika će bit UVEĆANA, al ne i umanjena 
                         ako je veća od zadane vrijednosti.
                    3 -> slika će biti umanjena ili uvećana.

                • Upotreba: -r:3

                Ako nije zadan argumnet za smanjivanje upotrijebit će se metoda 1                
        ----------------------------------------------------------------------------
        -t      -- NE RADI --
                Broj threadova (procesorskih dretvi/niti).

                • Upotreba: -t:8

                Ukoliko se ne upotrijebi argument za thread,
                tada će se koristiti threadova koliko ima jezgri procesora.

    
    Primjer:
                img_rsz.exe -w:1024 -f:l -t:2

                Slici će biti promijenjena širina na 1024px, 
                visina proprcionalno širini, 
                pri čemu će se koristiti Lanczos3 filter i
                2 procesorska threada.

    "    
}

pub fn about() {
    println!("\n • Made in Rust by {}\n", constants::AUTHOR);
}