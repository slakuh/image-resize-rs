//#![allow(dead_code)]
//#![allow(unused_variables)]

extern crate image;
extern crate user;

mod args_pars;
mod constants;
mod help;
mod img;
use args_pars::Arguments;
//use img::ImgSize;
//use std::io;
//use std::env;
/*
fn pause() {
	println!("\nPritisni ENTER za izlaz: ");
	//io::stdout().flush().unwrap();
	let mut input = String::new();
	io::stdin().read_line(&mut input).unwrap();
}
*/
fn main() {
    
    // prekinut će program ukoliko user nije definiran u user modulu
    user::user();
    
    println!("\n • Use \"-help\" argument for more information.\n");
    // args_pars::arguments();
    // args_pars::args_pars_main();
    //let mut file_vec: Vec<PathBuf> = Vec::new();
    let arg = Arguments::new();
    println!("\n");
    //img::resize_threaded(&arg);
    img::resize(&arg);
    //pause();
    //println!("\n\n\tGOTOVO!!!\n");
}